Sistema para criação de tarefas no estilo KanBan
